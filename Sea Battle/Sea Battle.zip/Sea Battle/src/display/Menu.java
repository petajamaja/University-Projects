
package display;

public class Menu {
    public static void displayMenu(){
        for(int i = 0; i<27; i++){
            System.out.println("\n");
        }
        System.out.println("+=================================+");
        System.out.println("|        GAME MENU                |");
        System.out.println("+=================================+");
        System.out.println("| Options:                        |");
        System.out.println("|        1. New game              |");
        System.out.println("|        2. Load game             |");
        System.out.println("|        3. Save game             |");
        System.out.println("|        4. Return to game        |");
        System.out.println("|        5. Quit                  |");
        System.out.println("|                                 |");
        System.out.println("+=================================+");
        System.out.println("|               =====             |");
        System.out.println("|             /_ || _\\            |");
        System.out.println("|             ========            |");
        System.out.println("|            /   ||   \\           |");
        System.out.println("|           /____|| ___\\          |");
        System.out.println("|           _____||_____          |");
        System.out.println("|           \\o o o o o /          |");
        System.out.println("|            \\________/           |");
        System.out.println("+=================================+");
        for(int j = 0; j <=2; j++){
            System.out.println();
        }
        
}
}